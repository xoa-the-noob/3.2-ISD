package com.example.charity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class editScheduleEvent extends AppCompatActivity {
    //date
    TextView startEventDate;
    TextView endEventDate;
    //for time
    TextView startEventTime,endEventTime;
    int t1Hour,t1Minute,t2Hour,t2Minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_schedule_event);
        //For date
        startEventDate=findViewById(R.id.editStartDate);
        endEventDate=findViewById(R.id.editEndDate);
        //for time
        startEventTime=findViewById(R.id.editStartTime);
        endEventTime=findViewById(R.id.editEndTime);

        //for chosing start event date
        final Calendar calendar =Calendar.getInstance();
        final int year=calendar.get(calendar.YEAR);
        final int month=calendar.get(calendar.MONTH);
        final int day=calendar.get(calendar.DAY_OF_MONTH);
        startEventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(
                        editScheduleEvent.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        month=month+1;
                        String date =dayOfMonth+"-"+month+"-"+year;
                        startEventDate.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });
        //for chosing end event date
        final Calendar calendar2 =Calendar.getInstance();
        final int year2=calendar2.get(calendar.YEAR);
        final int month2=calendar2.get(calendar.MONTH);
        final int day2=calendar2.get(calendar.DAY_OF_MONTH);
        endEventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(
                        editScheduleEvent.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year2, int month2, int dayOfMonth2) {
                        month2=month2+1;
                        String date =dayOfMonth2+"-"+month2+"-"+year2;
                        endEventDate.setText(date);
                    }
                },year2,month2,day2);
                datePickerDialog.show();
            }
        });
        //    //for chosing start event time
        startEventTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog=new TimePickerDialog(
                        editScheduleEvent.this, android.R.style.Theme_Holo_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                t1Hour=hourOfDay;
                                t1Minute=minute;
                                String time=t1Hour+":"+t1Minute;
                                SimpleDateFormat f24Hours= new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date=f24Hours.parse(time);
                                    SimpleDateFormat f12Hours = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    startEventTime.setText(f12Hours.format(date));
                                }catch (ParseException e){
                                    e.printStackTrace();
                                }

                            }
                        },12,0,false
                );
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.updateTime(t1Hour,t1Minute);
                timePickerDialog.show();
            }
        });
        //for chosing end event time
        endEventTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog=new TimePickerDialog(
                        editScheduleEvent.this, android.R.style.Theme_Holo_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                t2Hour=hourOfDay;
                                t2Minute=minute;
                                String time2=t2Hour+":"+t2Minute;
                                SimpleDateFormat f24Hours2= new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date2=f24Hours2.parse(time2);
                                    SimpleDateFormat f12Hours2 = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    endEventTime.setText(f12Hours2.format(date2));
                                }catch (ParseException e){
                                    e.printStackTrace();
                                }

                            }
                        },12,0,false
                );
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.updateTime(t2Hour,t2Minute);
                timePickerDialog.show();
            }
        });
    }
}